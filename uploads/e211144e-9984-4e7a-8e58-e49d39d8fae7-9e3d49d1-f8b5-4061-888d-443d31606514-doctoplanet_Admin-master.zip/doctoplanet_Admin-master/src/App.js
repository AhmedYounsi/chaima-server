/* eslint-disable */
import { Layout, Breadcrumb } from 'antd';
 
import { Route, Routes } from "react-router-dom";
import HeaderTab from './components/Header/HeaderTab';
 
import Sidebar from './components/SideBar/Sidebar';
import Home from "./pages/Home/Home";
import Patients from "./pages/Patients/Patients";
import Consultations from "./pages/Consultations/Consultations";
import Assurances from "./pages/Assurances/Assurances";
 
const { Sider } = Layout;

function App() {
  return (
<div>
<Layout>
 
    <HeaderTab />
    <Layout>
      <Sider width={236} className="site-layout-background">
         <Sidebar />
      </Sider>
      <Layout style={{ padding: 25 }}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/patients" element={<Patients />} />
        <Route path="/consultations" element={<Consultations />} />
        <Route path="/assurances" element={<Assurances />} />
      </Routes>
      </Layout>
    </Layout>
  </Layout>
</div>
  );
}

export default App;
