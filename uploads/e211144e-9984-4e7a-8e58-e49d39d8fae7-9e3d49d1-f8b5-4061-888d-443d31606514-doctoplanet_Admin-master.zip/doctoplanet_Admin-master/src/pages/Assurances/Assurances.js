import React from 'react'

function Assurances() {
  return (
    <div>Assurances</div>
  )
}

export default Assurances