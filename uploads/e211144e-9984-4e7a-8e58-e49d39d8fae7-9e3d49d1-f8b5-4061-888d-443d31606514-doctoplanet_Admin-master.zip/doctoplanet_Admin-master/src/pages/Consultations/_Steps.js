import React from "react";
import { Steps } from 'antd';
import { CheckCircleOutlined, FileDoneOutlined, CreditCardOutlined, VideoCameraOutlined } from '@ant-design/icons';

const { Step } = Steps;
function _Steps() {
  return (
    <Steps>

      <Step status="finish" title="Engegistrée" icon={<FileDoneOutlined />} />
      <Step status="process" title="Paiement" icon={<CreditCardOutlined />} />
      <Step status="wait" title="Consultation" icon={<VideoCameraOutlined />} />
      <Step status="wait" title="Terminée" icon={<CheckCircleOutlined />} />
    </Steps>
  );
}

export default _Steps;
