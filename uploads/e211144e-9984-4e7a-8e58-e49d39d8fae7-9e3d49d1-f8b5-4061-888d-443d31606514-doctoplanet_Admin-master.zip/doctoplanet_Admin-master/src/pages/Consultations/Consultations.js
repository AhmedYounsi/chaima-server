/* eslint-disable */
import React, { useEffect, useState } from "react";
import { Table, Space, PageHeader, Tag } from "antd";
import { GetAllPatients } from "../../actions/PatientActions";
import { Button } from "@blueprintjs/core";
import { SnippetsOutlined,ExclamationCircleOutlined  } from "@ant-design/icons";
import { useNavigate } from "react-router-dom";
import { GetAllConsult } from "../../actions/ConsultActions";
import _Steps from "./_Steps";
 
 
function Consultations() {
  const navigate = useNavigate();
  const [List, setList] = useState([]);
  const [ConsultDetails, setConsultDetails] = useState(null);
  useEffect(() => {
    GetAll();
  }, []);

  const GetAll = async () => {
    const res = await GetAllConsult();
    let arr = [];
    res.data.map((el, index) => {
      return arr.push({
        key: index,
        ...el,
      });
    });
    setList(arr);
  };

  const ShowDetails = (consultation) => {
    setConsultDetails(consultation);
    console.log(consultation);
  };

  const columns = [
    {
      title: "Patient",
      dataIndex: "nom",
      key: "nom",
      render: (nom, record) => <b> {record.nom + " " + record.prenom}</b>,
    },
    {
      title: "Consultation",
      dataIndex: "medecin",
      key: "medecin",
    
    },

    {
      title: "Début",
      dataIndex: "date_consul",
      key: "date_consul",
      render: (date_consul,record) => <p> {DateFormat(date_consul) +' - '+ record.heure_consul}</p>,
    },
    {
      title: "Etat",
      dataIndex: "etat",
      key: "etat",
      render: (etat,record) => <p> {etat == "0" ? 
      <Tag icon={<ExclamationCircleOutlined />} color="processing">
        En paiement
      </Tag>
      : etat == "1" ? "Consultation" : "terminée"} </p>,
    },
    

    {
      title: "Action",
      key: "action",
      render: (record) => (
        <Space size="middle">
          <Button onClick={() => ShowDetails(record)} className="custom_second">
            <SnippetsOutlined />
            <span style={{ marginLeft: 5 }}> Détails </span>
          </Button>
        </Space>
      ),
    },
  ];

  const DateFormat = (date) => {
    const dt = new Date(date);
    const year = dt.getFullYear();
    const month = (dt.getMonth() + 1).toString().padStart(2, "0");
    const day = dt.getDate().toString().padStart(2, "0");
    return day + '/' + month + '/' +year
  };

  return (
    <div>
      {ConsultDetails ? (
        <>
          <PageHeader
            className="site-page-header"
            onBack={() => setConsultDetails(null)}
            title={<p> Consultation Détails </p>}
            subTitle={ConsultDetails.nom + " " + ConsultDetails.prenom}
          />
          <_Steps />
        </>
      ) : (
        <>
          <PageHeader
            className="site-page-header"
            onBack={() => navigate("/")}
            title={<p>Consultations</p>}
            subTitle="Liste des consultation"
          />
          <Table  columns={columns} dataSource={List} />
        </>
      )}
    </div>
  );
}

export default Consultations;
