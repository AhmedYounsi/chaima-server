/* eslint-disable */
import React, { useEffect, useState } from "react";
import { Table, Space, PageHeader } from "antd";
import { GetAllPatients } from "../../actions/PatientActions";
import { Button } from "@blueprintjs/core";
import { SnippetsOutlined } from "@ant-design/icons";
import { useNavigate } from "react-router-dom";
import Info from "./Info";


function Patients() {
  const navigate = useNavigate()
  const [List, setList] = useState([]);
  const [UserDetails, setUserDetails] = useState(null)
  useEffect(() => {
    GetAll();
  }, []);

  const GetAll = async () => {
    const res = await GetAllPatients();
    let arr = [];
    res.data.map((el, index) => {
      return arr.push({
        key: index,
        ...el,
      });
    });
    setList(arr);
  };

  const ShowDetails = (patient) =>{
    setUserDetails(patient)
    console.log(patient)
  }

  const columns = [
    {
      title: "Patient",
      dataIndex: "nom",
      key: "nom",
     render: (nom,record) => <b> {record.nom +" "+ record.prenom}</b>,
    },
   
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
    {
      title: "Téléphone",
      dataIndex: "tel",
      key: "tel",
    },
    {
      title: "Date de naissance",
      dataIndex: "date_naissance",
      key: "date_naissance",
      render: (date_naissance) => <p> {date_naissance}</p>,
    },

    {
      title: "Action",
      key: "action",
      render: (record) => (
        <Space size="middle">
          <Button onClick={() => ShowDetails(record)} className="custom_second">
            <SnippetsOutlined />
            <span style={{ marginLeft: 5 }}> Détails </span>
          </Button>
        </Space>
      ),
    },
  ];



  return (
    <div>
    {

      UserDetails ?
      <>
      <PageHeader
         className="site-page-header"
         onBack={() =>setUserDetails(null)}
         title={<p> Patient Détails </p>}
         subTitle={UserDetails.nom +" " +UserDetails.prenom}
       />
       <Info />
      
      </>
      :
       <>
       <PageHeader
          className="site-page-header"
          onBack={() => navigate("/")}
          title={<p>Patients</p>}
          subTitle="Liste des patients inscrits"
        />
        <Table columns={columns} dataSource={List} />
       </>
    }
    </div>
  );
}

export default Patients;
