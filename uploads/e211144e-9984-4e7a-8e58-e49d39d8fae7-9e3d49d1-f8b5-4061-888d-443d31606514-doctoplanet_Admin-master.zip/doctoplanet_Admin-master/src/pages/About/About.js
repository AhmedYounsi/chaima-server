import React, { useState } from 'react'
import { Tab, Tabs } from "@blueprintjs/core";

function About() {
  const [Selected, setSelected] = useState("ng")
  return (
    <div>
      <Tabs id="TabsExample" onChange={(e)=>setSelected(e)} selectedTabId={Selected}>
    <Tab id="ng" title="Angular" panel={"zzer"} />
    <Tab id="mb" title="Ember" panel={"sdfsdf"} panelClassName="ember-panel" />
    <Tab id="rx" title="React" panel={"qsdsfsdf"} />
    
    <Tabs.Expander />
    <input className="bp3-input" type="text" placeholder="Search..." />
</Tabs>
    </div>
  )
}

export default About