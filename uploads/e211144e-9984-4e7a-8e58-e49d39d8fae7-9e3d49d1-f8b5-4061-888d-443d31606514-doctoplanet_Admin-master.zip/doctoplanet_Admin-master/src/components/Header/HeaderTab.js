import React from "react";
import Logo from "../../assets/images/Logo doctoplanet.png";
import "./HeaderTab.scss";

function HeaderTab() {
  return (
    <nav className="bp3-navbar bp3-dark">
      <div className="bp3-navbar-group bp3-align-left">
        <div className="bp3-navbar-heading">
          <img className="Logo" src={Logo} alt="" />
        </div>
      </div>
      <div className="bp3-navbar-group bp3-align-right">
      <button className="bp3-button bp3-minimal bp3-icon-user">Hamouda Younsi</button>
        <span className="bp3-navbar-divider"></span>
     
        <button className="bp3-button bp3-minimal bp3-icon-notifications"></button>
        <button className="bp3-button bp3-minimal bp3-icon-cog"></button>
      </div>
    </nav>
  );
}

export default HeaderTab;
