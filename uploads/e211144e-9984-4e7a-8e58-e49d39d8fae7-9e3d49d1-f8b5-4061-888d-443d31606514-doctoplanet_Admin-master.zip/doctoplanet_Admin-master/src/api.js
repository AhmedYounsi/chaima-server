/* eslint-disable */
const url_local = "http://localhost:5000"
const url_vps = "https://doctoplanet.com"
const url = url_local
export default url;